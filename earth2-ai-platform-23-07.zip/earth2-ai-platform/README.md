# Earth2 AI Platform
Stage 1 scaffold.
