from pydantic_settings import BaseSettings
class Settings(BaseSettings):
    app_name='Earth2 AI'
settings=Settings()
