from pydantic import BaseModel
class ForecastRequest(BaseModel):
    lat:float
    lon:float
