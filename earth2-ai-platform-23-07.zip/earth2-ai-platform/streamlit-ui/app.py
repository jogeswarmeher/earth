import streamlit as st
st.title('Earth2 AI Platform')
