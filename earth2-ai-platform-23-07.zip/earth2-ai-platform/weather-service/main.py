from fastapi import FastAPI
app=FastAPI(title='Weather Service')
@app.get('/health')
def health(): return {'status':'ok'}
